package com.iispl.service.utility;

import java.util.ArrayList;
import java.util.Scanner;

import com.iispl.entity.Account;
import com.iispl.service.AccountService;

public class AccountUtility {

	public static void main(String[] args) {

		ArrayList<Account> accountList = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		char mainchoice;

		do {

			System.out.println("1.create account, 2.display account details");
			int choice = sc.nextInt();

			switch (choice) {

			case 1:
				Account account = AccountService.createAccount();
				if (account != null) {
					accountList.add(account);
				}
				break;

			case 2:
				AccountService.displayAccounts(accountList);
				break;

			default:
				System.out.println("Invalid option...");
			}

			System.out.println("do you want to continue(y/n)");
			mainchoice = sc.next().charAt(0);

		} while (mainchoice == 'y');

		System.out.println("thank you for visiting....");
	}
}
