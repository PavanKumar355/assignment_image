package com.iispl.entity;

public class CurrentAccount extends Account {
private String gstNo;

public CurrentAccount(String accountNumber, String accountHolderName, double balance, String gstNo) {
	super(accountNumber, accountHolderName, balance);
	this.gstNo = gstNo;
}

public String getGstNo() {
	return gstNo;
}



}
