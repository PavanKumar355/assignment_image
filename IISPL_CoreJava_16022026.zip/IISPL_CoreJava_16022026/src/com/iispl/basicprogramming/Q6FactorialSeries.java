package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q6FactorialSeries {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter n value: ");
        int n = sc.nextInt();

        double sum = 0;
        long fact = 1;   // to store factorial

        for(int i = 1; i <= n; i++) {

            fact = fact * i;        // calculate i!
            sum = sum + (double)i / fact;   // formula applied here( i / i!)
        }

        System.out.println("Sum of series = " + sum);
    }
}
// formula: 
// term = i/i!
