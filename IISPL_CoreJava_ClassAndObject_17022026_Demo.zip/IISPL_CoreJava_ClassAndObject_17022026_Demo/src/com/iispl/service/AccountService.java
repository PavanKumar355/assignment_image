package com.iispl.service;

import java.util.Scanner;
import com.iispl.entity.Account;

public class AccountService {

    public static Account createAccount() {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Account number: ");
        String accountNumber = scanner.nextLine();

        System.out.print("Enter the accountHolderName: ");
        String accountHolderName = scanner.nextLine();

        System.out.print("Enter the initial Balance: ");
        double initialBalance = scanner.nextDouble();

        Account account = new Account(accountNumber,accountHolderName,initialBalance);
        account.setAccountHolderName(accountHolderName);
        account.setAccountNumber(accountNumber);
        account.setBalance(initialBalance);

        return account;
    }
}
