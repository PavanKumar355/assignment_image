package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q3AlternatingSeries {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        int sum = 0;

        for(int i = 1; i <= n; i++) {

            int term = 2*i - 1;   // generates 1,3,5,7,...

            if(i % 2 == 0) {
                sum = sum - term;   // even position -> minus
            } else {
                sum = sum + term;   // odd position -> plus
            }
        }

        System.out.println("Sum of series = " + sum);
    }
}
