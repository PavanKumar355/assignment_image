package com.iispl.basicprogramming;
import java.util.*;
public class Q4NumberSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.println("Enter the n value: ");
int n = sc.nextInt();

int sum = 0;
for(int i=1; i<=n; i++) {
	sum = sum + i*i*i;
}
System.out.println(sum);
	}

}
