package com.iispl.basicprogramming;
import java.util.*;

public class Q13OccurenceOfNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.print("Enter the array length: ");
int arrayLength = sc.nextInt();
int[] numberList = new int[arrayLength];

System.out.print("Enter array elements: ");
for(int i=0; i<arrayLength; i++) {
	numberList[i] = sc.nextInt();
}

findOccurrence(numberList);

	}
	
	public static void findOccurrence(int[] numList) {
		int[] arr = new int[numList.length];
		for(int num: numList) {
			arr[num] = arr[num] + 1;
		}
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i]>0) {
				System.out.println("The occurrence of "+i+" : "+arr[i]);
			}
		}
		
	}

}
