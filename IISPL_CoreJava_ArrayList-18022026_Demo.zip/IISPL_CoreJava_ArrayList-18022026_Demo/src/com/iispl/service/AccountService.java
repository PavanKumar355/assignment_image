package com.iispl.service;

import java.util.ArrayList;
import java.util.Scanner;

import com.iispl.entity.Account;
import com.iispl.entity.CurrentAccount;
import com.iispl.entity.SavingsAccount;

public class AccountService {

	public static Account createAccount() {

		Scanner scanner = new Scanner(System.in);

		String gstNo = "NA";
		String roi = "NA";

		System.out.println("1.Savings, 2.Current");
		int accountType = scanner.nextInt();
		scanner.nextLine(); // clear buffer

		System.out.print("Enter Account number: ");
		String accountNumber = scanner.nextLine();

		System.out.print("Enter the accountHolderName: ");
		String accountHolderName = scanner.nextLine();

		System.out.print("Enter the initial Balance: ");
		double initialBalance = scanner.nextDouble();
		scanner.nextLine();

		Account account = null;

        
		if (accountType == 1) {
			roi = "5%";  
			account = new SavingsAccount(accountNumber, accountHolderName, initialBalance, roi);
		}

		if (accountType == 2) {
			System.out.print("Enter GST No: ");
			gstNo = scanner.nextLine();
			account = new CurrentAccount(accountNumber, accountHolderName, initialBalance, gstNo);
		}

		return account;
	}

	public static void displayAccounts(ArrayList<Account> accountList) {
		if(accountList.isEmpty()) {
        	System.out.println("Kindly create account first....");
        }

		for (Account account : accountList) {

			String type = "NA";
			String gstNo = "NA";
			String roi = "NA";
            
			if (account instanceof SavingsAccount) {
				type = "Savings";
				roi = ((SavingsAccount) account).getRoi();
			}

			if (account instanceof CurrentAccount) {
				type = "Current";
				gstNo = ((CurrentAccount) account).getGstNo();
			}

			System.out.println("type: " + type);
			System.out.println("account number: " + account.getAccountNumber());
			System.out.println("account holder name: " + account.getAccountHolderName());
			System.out.println("balance: " + account.getBalance());
			System.out.println("gstno: " + gstNo);
			System.out.println("roi: " + roi);
			System.out.println("--------------------------------");
		}
	}
}
