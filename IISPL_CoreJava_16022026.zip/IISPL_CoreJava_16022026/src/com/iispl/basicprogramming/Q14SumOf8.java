package com.iispl.basicprogramming;
import java.util.*;
public class Q14SumOf8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int[] numberList = {2,6,4,1,5,1};
int target = 8;
findSum(numberList,target);
	}

	private static void findSum(int[] numberList,int target) {
		int length = numberList.length;
		ArrayList<ArrayList<Integer>> list = new ArrayList<>();
		list.add(new ArrayList<>());
		for(int num: numberList) {
			int size = list.size();
			for(int i=0; i<size; i++) {
				ArrayList<Integer> newList = new ArrayList<>(list.get(i));
				newList.add(num);
				list.add(newList);
				
				int sum =0;
				for(int val: newList) {
					sum += val;
				}
				if(sum == target) System.out.println(newList);
			} 
		}
		
		
	}
	

}
