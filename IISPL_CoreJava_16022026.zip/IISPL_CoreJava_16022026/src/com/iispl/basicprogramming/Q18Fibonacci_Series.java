package com.iispl.basicprogramming;
import java.util.*;
public class Q18Fibonacci_Series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.print("Enter the length: ");
int n = sc.nextInt();
if(n<=1) {
	System.out.print("0 1");
}
else {
	int a = 0,b=1;
	System.out.print("0 1");
	for(int i=2; i<n; i++) {
		int sum = a+b;
		System.out.print(" "+sum+" ");
		b=sum;
		a=b;
	}
}
	}

}
