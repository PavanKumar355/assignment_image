package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q2AscendingAndDescending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner  sc = new Scanner(System.in);
System.out.print("Enter four numbers: ");
int[] arr = new int[4];
for(int i=0; i<4;i++) {
	arr[i] = sc.nextInt();
}
descendingOrder(arr);
ascendingOrder(arr);
	}
	public static void descendingOrder(int[] a) {
		
int size = a.length;
for(int i=0; i<size; i++) {
	for(int j=i+1; j<size; j++) {
		if(a[i]<a[j]) {
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	}
}
for(int i=0; i<size; i++) {
	System.out.print(a[i]+" ");
}
System.out.println();
		}

	public static void ascendingOrder(int[] a) {
		
		int size = a.length;
		for(int i=0; i<size; i++) {
			for(int j=i+1; j<size; j++) {
				if(a[i]>a[j]) {
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		for(int i=0; i<size; i++) {
			System.out.print(a[i]+" ");
		}
				}

}
