package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q7SeriesSquareFactorial {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        double sum = 0;

        for(int i = 1; i <= n; i++) {

            int num = i * i;   // i^2
            long fact = 1;

            // calculate (i^2)!
            for(int j = 1; j <= num; j++) {
                fact = fact * j;
            }

            sum = sum + (double)i / fact;
        }

        System.out.println("Sum of series = " + sum);
    }
}
// formula
// term = i / ( (i*i)! )

