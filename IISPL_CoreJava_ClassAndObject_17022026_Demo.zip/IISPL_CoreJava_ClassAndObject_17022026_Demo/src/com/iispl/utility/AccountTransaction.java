package com.iispl.utility;

import java.util.Scanner;

import com.iipsl.service.Service;
import com.iispl.entity.Account;
import com.iispl.service.AccountService;

public class AccountTransaction {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("1. create account, 2.display");
        int choice = sc.nextInt();

        switch (choice) {

            case 1:
                Account account = AccountService.createAccount();
                displayAccount(account);
                break;
        }
    }

    private static void displayAccount(Account account) {

        System.out.println("Account holder name: " + account.getAccountHolderName());
        System.out.println("Account Balance: " + account.getBalance());
        System.out.println("Account number: " + account.getAccountNumber());
    }
}

