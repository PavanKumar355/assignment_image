package com.iispl.basicprogramming;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Q20ValidationOfProduct {
	String productName;
	LocalDate validityDate;
	LocalDate expiryDate;
	
	

	public Q20ValidationOfProduct(String productName, LocalDate validityDate, LocalDate expiryDate) {
		this.productName = productName;
		this.validityDate = validityDate;
		this.expiryDate = expiryDate;
	}
	
	void checkPurchase(LocalDate purchaseDate) {
		System.out.println("Product: "+productName);
		System.out.println("Expiry Date: "+expiryDate);
		if(purchaseDate.isAfter(validityDate)) System.out.println("Cannot purchase...");
		else System.out.println("Purchase..");
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
System.out.print("Enter the product name: ");
String name = sc.nextLine();

System.out.print("Enter validity date(yyyy-MM-dd): ");
LocalDate validity = LocalDate.parse(sc.nextLine(), formatter);
System.out.print("Enter expiry date(yyyy-MM-dd): ");
LocalDate expiry = LocalDate.parse(sc.nextLine(), formatter);

Q20ValidationOfProduct product = new Q20ValidationOfProduct(name,validity,expiry);
System.out.print("Enter purchase date(yyyy-MM-dd): ");
LocalDate purchaseDate = LocalDate.parse(sc.nextLine(), formatter);

product.checkPurchase(purchaseDate);
	}

}
