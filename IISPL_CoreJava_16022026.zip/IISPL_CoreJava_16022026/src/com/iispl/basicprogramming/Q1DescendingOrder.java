package com.iispl.basicprogramming;
import java.util.*;
public class Q1DescendingOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner  sc = new Scanner(System.in);
System.out.print("Enter three numbers: ");
int[] arr = new int[3];
for(int i=0; i<3;i++) {
	arr[i] = sc.nextInt();
}
descendingOrder(arr);

	}
	public static void descendingOrder(int[] a) {
		
int size = a.length;
for(int i=0; i<size; i++) {
	for(int j=i+1; j<size; j++) {
		if(a[i]<a[j]) {
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	}
}
for(int i=0; i<size; i++) {
	System.out.println(a[i]+" ");
}
		}

}
