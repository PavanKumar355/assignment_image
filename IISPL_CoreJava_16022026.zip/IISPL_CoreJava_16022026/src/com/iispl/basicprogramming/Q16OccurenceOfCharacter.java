package com.iispl.basicprogramming;
import java.util.*;
public class Q16OccurenceOfCharacter {

public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.print("Enter the string: ");
String str = sc.nextLine();

findOccurence(str);
	}

private static void findOccurence(String str) {
	// TODO Auto-generated method stub
	int count =0;
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter the character to find occurence: ");
	char ch = sc.next().charAt(0);
	for(int i=0; i<str.length(); i++) {
		char chr = str.charAt(i);
		if(ch== chr) {
			count++;
			str=str.replace(chr, '@');
		}
	}
	System.out.println("occurence of character "+ch+": "+count);
	System.out.println(str);
	
}
}
