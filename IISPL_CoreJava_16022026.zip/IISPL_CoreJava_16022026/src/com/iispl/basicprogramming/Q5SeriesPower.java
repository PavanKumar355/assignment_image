package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q5SeriesPower {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        long sum = 0;

        for(int i = 1; i <= n; i++) {

            int base = 2*i - 1;   // generates 1,3,5,7...
            long power = 1;

            // calculate base^i without Math.pow
            for(int j = 1; j <= i; j++) {
                power = power * base;
            }

            if(i % 2 == 0) {
                sum = sum - power;   // even -> minus
            } else {
                sum = sum + power;   // odd -> plus
            }
        }

        System.out.println("Sum of series = " + sum);
    }
}

