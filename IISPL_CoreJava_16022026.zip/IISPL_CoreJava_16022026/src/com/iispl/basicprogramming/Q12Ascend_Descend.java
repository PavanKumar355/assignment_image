package com.iispl.basicprogramming;

import java.util.Arrays;
import java.util.Scanner;

public class Q12Ascend_Descend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner  sc = new Scanner(System.in);
System.out.print("Enter four numbers: ");
int[] arr = new int[4];
for(int i=0; i<4;i++) {
	arr[i] = sc.nextInt();
}
descendingOrder(arr);
ascendingOrder(arr);

	}
	public static void ascendingOrder(int[] arr) {
		// TODO Auto-generated method stub
		Arrays.sort(arr);
		System.out.print("Ascending order: ");
		for(int i=0;i<4; i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void descendingOrder(int[] a) {
		
Arrays.sort(a);
System.out.print("Descending order: ");
for(int i=3;i>=0; i--) {
	System.out.print(a[i]+" ");
}
System.out.println();
		}

}
