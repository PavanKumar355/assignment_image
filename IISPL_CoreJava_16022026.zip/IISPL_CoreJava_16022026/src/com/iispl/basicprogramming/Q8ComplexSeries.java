package com.iispl.basicprogramming;

import java.util.Scanner;

public class Q8ComplexSeries {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        double sum = 0;
        long fact = 1;

        for(int i = 1; i <= n; i++) {

            int square = i * i;   // i^2

            // calculate (i^2)^i
            long power = 1;
            for(int j = 1; j <= i; j++) {
                power = power * square;
            }

            // calculate i!
            fact = fact * i;

            sum = sum + (double)i / (power + fact);
        }

        System.out.println("Sum of series = " + sum);
    }
}

