package com.iispl.basicprogramming;
import java.util.*;
public class Q11FrequencyOfElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.print("Enter the elements: ");
int n = sc.nextInt();
int[] arr = new int[n];
for(int i=0;i<n;i++) {
	arr[i] = sc.nextInt();
}
frequencyOfElement(arr);
	}

	public static void frequencyOfElement(int[] arr) {
		
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the element to find the frequency: ");
		int element = sc.nextInt();
		int count = 0;
		for(int i=0; i<arr.length; i++) {
			if(arr[i]==element)count++;
		}
		System.out.println("the freqency of element "+element+" is "+count);
		
	}

}
