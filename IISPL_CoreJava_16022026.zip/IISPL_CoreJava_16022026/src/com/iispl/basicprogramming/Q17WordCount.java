package com.iispl.basicprogramming;
import java.util.*;
import java.util.Scanner;

public class Q17WordCount {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter sentence: ");
        String str = sc.nextLine();

        int count = 0;
        boolean inWord = false;

        for(int i = 0; i < str.length(); i++) {

            if(str.charAt(i) != ' ' && inWord == false) {
                count++;
                inWord = true;
            }
            else if(str.charAt(i) == ' ') {
                inWord = false;
            }
        }

        System.out.println("Word count = " + count);
    }
}
