package com.iispl.entity;

public class SavingsAccount extends Account {
private String roi;

public SavingsAccount(String accountNumber, String accountHolderName, double balance, String roi) {
	super(accountNumber, accountHolderName, balance);
	this.roi = "5%";
}

public String getRoi() {
	return roi;
}
}
