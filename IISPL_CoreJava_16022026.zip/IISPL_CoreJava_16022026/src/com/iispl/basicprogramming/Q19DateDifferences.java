package com.iispl.basicprogramming;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Q19DateDifferences {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // define input format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        System.out.print("Enter first date (dd-MM-yyyy): ");
        String input1 = sc.nextLine();

        System.out.print("Enter second date (dd-MM-yyyy): ");
        String input2 = sc.nextLine();

        // convert String → LocalDate using format
        LocalDate date1 = LocalDate.parse(input1, formatter);
        LocalDate date2 = LocalDate.parse(input2, formatter);

        // calculate difference
        Period diff = Period.between(date1, date2);

        System.out.println("Years  : " + diff.getYears());
        System.out.println("Months : " + diff.getMonths());
        System.out.println("Days   : " + diff.getDays());
    }
}
